<?php
	
	$produtos = array("Pneu", "Oleo", "Luvas");

	foreach ($produtos as $key) {
		echo $key."<br>";
	}
		
?> 