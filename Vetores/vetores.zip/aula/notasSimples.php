<?php
	$notas = array(5,8,7);
	
	echo "O maior valor é:" . max($notas);
	
?>